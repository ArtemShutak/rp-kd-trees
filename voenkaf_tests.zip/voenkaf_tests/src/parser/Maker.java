package parser;

public interface Maker {

	void addQuestion(int number, String question, String[] answers,
			String trueAnswers);

	void finish();

}
