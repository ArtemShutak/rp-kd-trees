package parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Parser {
	

	private static final String answersFileName = "answersXML.xml";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Parser parser = new Parser();
		parser.parse(answersFileName, Arrays.asList(new Maker[] {new PrintMaker(), new XMLMaker()}));
	}
	
	public static void parse(String answFileName, List<Maker> makers){
		try {
			Scanner sc = null;
			sc = new Scanner(new File(answFileName));
			int number = 0;
			while (sc.hasNextLine()) {
				//int number = sc.nextInt();
				number++;
				int numberLettersForNumberQuestionInPrefix = 2;
				if(number>9){
					numberLettersForNumberQuestionInPrefix = 3;
				}
				if(number>99){
					numberLettersForNumberQuestionInPrefix = 4;
				}
				String question = sc.nextLine().substring(numberLettersForNumberQuestionInPrefix  );
				String[] answers = new String[4];
				for (int i = 0; i < answers.length; i++) {
					answers[i] = sc.nextLine().substring(2);					
				}
				String trueAnswers = sc.nextLine();
				for (Maker maker : makers) {
					maker.addQuestion(number,question,answers,trueAnswers);					
				}
			}
			for (Maker maker : makers) {
				maker.finish();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
