package parser;

import java.util.HashSet;
import java.util.Set;

public class PrintMaker implements Maker {
	private Set<Integer> numbers = new HashSet<Integer>();

	@Override
	public void addQuestion(int number, String question, String[] answers,
			String trueAnswers) {
		if(numbers.contains(number)){
			throw new IllegalStateException("����� ����� ��� ����");
		}
		numbers.add(number);
		System.out.println("Q"+number+" :");
		System.out.println("	quest =" + question);
		for (int i = 0; i < answers.length; i++) {
			System.out.println("	answ["+i+"] = " + answers[i]);
		}
		System.out.println("	true quest = " + trueAnswers);
	}

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		
	}

}
