package parser;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import test.Question;

public class XMLMaker implements Maker {
	public static final String xmlOutFileName = "answersXML.xml";
	private BufferedWriter out;
	private StringBuilder xmlStr = new StringBuilder();
	
	public XMLMaker(){
		xmlStr.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+
		"<questions>");
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(xmlOutFileName,false)));
			out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			out.newLine();
			out.write("<questions>");
			out.newLine();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void addQuestion(int number, String question, String[] answers,
			String trueAnswers) {
		try {
			xmlStr.append("<"+Question.QUESTION+" number=\""+number+"\"> \n");
			out.write("<"+Question.QUESTION+" number=\""+number+"\">");out.newLine();
			
			xmlStr.append("<"+Question.QUESTION_TEXT + ">").append(question).append("</"+Question.QUESTION_TEXT + "> \n");
			xmlStr.append("<"+Question.ANSWER1 + ">").append(answers[0]).append("</"+Question.ANSWER1 + "> \n");
			xmlStr.append("<"+Question.ANSWER2 + ">").append(answers[1]).append("</"+Question.ANSWER2 + "> \n");
			xmlStr.append("<"+Question.ANSWER3 + ">").append(answers[2]).append("</"+Question.ANSWER3 + "> \n");
			xmlStr.append("<"+Question.ANSWER4 + ">").append(answers[3]).append("</"+Question.ANSWER4 + "> \n");
			xmlStr.append("<"+Question.TRUE_ANSWER + ">").append(trueAnswers).append("</"+Question.TRUE_ANSWER + "> \n");

			out.write("<"+Question.QUESTION_TEXT + ">" + question + "</"+Question.QUESTION_TEXT + "> \n");  out.newLine();
			out.write("<"+Question.ANSWER1 + ">" + answers[0] + "</"+Question.ANSWER1 + "> \n");  out.newLine();
			out.write("<"+Question.ANSWER2 + ">" + answers[1]+ "</"+Question.ANSWER2 + "> \n");  out.newLine();
			out.write("<"+Question.ANSWER3 + ">" + answers[2] + "</"+Question.ANSWER3 + "> \n");  out.newLine();
			out.write("<"+Question.ANSWER4 + ">" + answers[3] + "</"+Question.ANSWER4 + "> \n");  out.newLine();
			out.write("<"+Question.TRUE_ANSWER + ">" + trueAnswers + "</"+Question.TRUE_ANSWER + "> \n");  out.newLine();
			
			xmlStr.append("</"+Question.QUESTION + "> \n");
			out.write("</"+Question.QUESTION + "> \n");out.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void finish() {
		xmlStr.append("</questions>");		
		try {
			out.write("</questions>");
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
