package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import parser.XMLMaker;

public class Question {
	public static final String answersFileName = "bin/test/answersXML.xml";//XMLMaker.xmlOutFileName;
	public static final String QUESTION = "question";
	public static final String NUMBER = "number";
	public static final String QUESTION_TEXT = "qtext";
	public static final String ANSWER1 = "ans1";
	public static final String ANSWER2 = "ans2";
	public static final String ANSWER3 = "ans3";
	public static final String ANSWER4 = "ans4";
	public static final String TRUE_ANSWER = "trueAns";
	
	private static NodeList questions;
	private static int numberQuestions;
	
	private String myQuestionText;
	private boolean[] myTrueAnswer = new boolean[4];
	private String[] myAnswers = new String[4];
	private String trueAnswerForTest;

	static {
		String allAnswersText = getAllAnswersText();
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			InputSource inputSource = new InputSource(new StringReader(
					allAnswersText));
			document = builder.parse(inputSource);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			System.out.println(allAnswersText);
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		questions = document.getDocumentElement()
				.getElementsByTagName(QUESTION);
		numberQuestions = questions.getLength();
	}
	/**
	 * 
	 * @param number >= 1
	 */
	public Question(int number) {
		int questionID = getQuestionID(number-1);
		Element questionElement = getQuestionElement(questionID);
		myQuestionText = editString(questionElement.getElementsByTagName(QUESTION_TEXT)
				.item(0).getTextContent());
		myAnswers[0] = editString(questionElement.getElementsByTagName(ANSWER1).item(0)
				.getTextContent());
		myAnswers[1] = editString(questionElement.getElementsByTagName(ANSWER2).item(0)
				.getTextContent());
		myAnswers[2] = editString(questionElement.getElementsByTagName(ANSWER3).item(0)
				.getTextContent());
		myAnswers[3] = editString(questionElement.getElementsByTagName(ANSWER4).item(0)
				.getTextContent());
		String trueAnswer = editString(questionElement.getElementsByTagName(TRUE_ANSWER)
				.item(0).getTextContent());
		trueAnswerForTest = trueAnswer;
		calculTrueAnswers(trueAnswer);
	}

	private String editString(String text) {
		Set<Character> simbolsForDelete = new HashSet<Character>();
		simbolsForDelete.addAll(Arrays.asList(new Character[] {' ',',','.','\t'}));
		for (int index = 0; index < text.length(); index++) {
			if(!simbolsForDelete.contains(text.charAt(index))){
			//if(text.charAt(index)!=' '){
				return text.substring(index);
			}			
		}
		/*for (StringTokenizer sTokenizer = new StringTokenizer(text," .,"); sTokenizer.hasMoreTokens(); ) {
			sTokenizer.
		}*/
		return "";
	}

	private void calculTrueAnswers(String trueAnswers) {
		for (StringTokenizer sTokenizer = new StringTokenizer(trueAnswers," ,."); sTokenizer
				.hasMoreTokens();) {
			char number = sTokenizer.nextToken().charAt(0);
			switch (number) {
			case '1':
				myTrueAnswer[0]=true;
				break;
			case '2':
				myTrueAnswer[1]=true;
				break;
			case '3':
				myTrueAnswer[2]=true;
				break;
			case '4':
				myTrueAnswer[3]=true;
				break;
			default:
				throw new IllegalStateException("trueAnswer string: "+ trueAnswers +"number question = " + number);
			}
		}
	}

	/**
	 * 
	 * @param questionID - from 1 to numberQuestions
	 * @return
	 */
	private Element getQuestionElement(int questionID) {
		for (int i = 0; i < questions.getLength(); i++) {
			// if(questions.item(i).getAttributes().getNamedItem("number").equals(questionID)){
			if (((Element) questions.item(i)).getAttribute(NUMBER).equals(
					""+questionID)) {
				return (Element) questions.item(i);
			}
		}
		throw new IllegalArgumentException(
				"There is not question with number = " + questionID);
	}

	private static String getAllAnswersText() {
		Scanner sc = null;
		try {
			sc = new Scanner(new File(answersFileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		StringBuilder stringBuilder = new StringBuilder();
		while (sc.hasNextLine()) {
			stringBuilder.append(sc.nextLine());
		}
		return stringBuilder.toString();
	}
	/**
	 * 
	 * @param number - from 0 to numberQuestions-1
	 * @return
	 */
	private int getQuestionID(int number) {
		int standartInterval = numberQuestions/Test.NUMBER_QUESTIONS;
		int baseNumber = standartInterval * number;
		int nextBaseNumber = standartInterval * (number+1);
		if(number == numberQuestions-1){
			nextBaseNumber = numberQuestions;
		}
		return baseNumber + (new Random().nextInt(nextBaseNumber)%(nextBaseNumber-baseNumber));
	}

	public String getQuestionText() {
		return myQuestionText;
	}

	public String getAnswer(int number) {
		return myAnswers[number-1];
	}

	public boolean hasThis(boolean[] answer) {
		for (int i = 0; i < myTrueAnswer.length; i++) {
			if(myTrueAnswer[i]!=answer[i]){
				return false;
			}
		}
		return true;
	}

	public boolean haveSeveralTrueAnswers() {
		int countTrueAnsw = 0;
		for (int i = 0; i < myTrueAnswer.length; i++) {
			if(myTrueAnswer[i]){
				countTrueAnsw++;
			}
		}
		if(countTrueAnsw>1){
			return true;
		}
		return false;
	}

}
