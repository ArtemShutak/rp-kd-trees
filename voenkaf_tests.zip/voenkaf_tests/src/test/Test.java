package test;

import java.util.Collection;

public class Test {

	public static final int NUMBER_QUESTIONS = 10;
	private int myCurQuestionNumber = -1;//from 0 to NUMBER_QUESTIONS-1
	private boolean[][] myAnswers = new boolean[NUMBER_QUESTIONS][4];
	private Question[] myQuestions;
	private int myNumberOfTrueAnswers = -1;

	public Test() {
		initQuestions();
	}

	private void initQuestions() {
		myQuestions = new Question[NUMBER_QUESTIONS];
		for (int i = 0; i < myQuestions.length; i++) {
			myQuestions[i] = new Question(i + 1);
		}
	}

	public Question getNextQuestionAndReciveAnswer(boolean[] answer) {
		myAnswers[myCurQuestionNumber] = answer;
		return nextQuestion();
	}

	public Question getPreviousQuestionAndReciveAnswer(boolean[] answer) {
		myAnswers[myCurQuestionNumber] = answer;
		return previousQuestion();
	}

	public Question getFirstQuestion() {
		return nextQuestion();
	}

	private Question nextQuestion() {
		myCurQuestionNumber++;
		if (myCurQuestionNumber >= NUMBER_QUESTIONS) {
			return null;
		}
		return myQuestions[myCurQuestionNumber];
	}

	private Question previousQuestion() {
		myCurQuestionNumber--;
		if (myCurQuestionNumber < 0) {
			myCurQuestionNumber = 0;
			return null;
		}
		return myQuestions[myCurQuestionNumber];
	}

	public int getMark() {
		int mark = 2;
		if(getNumberOfTrueAnswers()==7){
			mark=3;
		}
		if(getNumberOfTrueAnswers()==8){
			mark=4;
		}
		if(getNumberOfTrueAnswers()>8){
			mark=5;
		}
		return mark;
	}

	public int getNumberOfTrueAnswers() {
		myNumberOfTrueAnswers = 0;
		for (int i = 0; i < myAnswers.length; i++) {
			if (myQuestions[i].hasThis(myAnswers[i])) {
				myNumberOfTrueAnswers++;
			}
		}

		return myNumberOfTrueAnswers;
	}

	public void run() {
		TestJFrame myFrame = new TestJFrame(this);
		myFrame.setVisible(true);
	}

	public static void main(String[] args) {
		Test test = new Test();
		test.run();
		int numberOfTrueAnswers = test.getNumberOfTrueAnswers();
		int mark = test.getMark();

	}

	public int getQuestionNumber() {
		return myCurQuestionNumber + 1;
	}

	public boolean[] getCurAnswerOnCurQuestion() {
		return myAnswers[myCurQuestionNumber];
	}

	public String getInstructions() {
		if(myQuestions[myCurQuestionNumber].haveSeveralTrueAnswers()){
			return "�������� ���������� ������(�� ���������)";
		}
		return "�������� ���������� �����";
	}
	public String createReport(){
		String report = "����� ��������:     " + Test.NUMBER_QUESTIONS + 
				                "\n���������� �������: " + this.getNumberOfTrueAnswers() + 
				                "\n������:             " + this.getMark();
		if(getNumberOfTrueAnswers()<NUMBER_QUESTIONS){
			report+="\n������������ ������:";
			for (int i = 0; i < myAnswers.length; i++) {
				if (!myQuestions[i].hasThis(myAnswers[i])) {
					report+="\n"+ (i+1) + "."+myQuestions[i].getQuestionText();
					for (int j = 0; j < 4; j++) {
						if(myAnswers[i][j]){
							report+="\n-- "+ myQuestions[i].getAnswer(j+1);
						}
					}
				}
			}			
		}
		return report ;
	}
}
